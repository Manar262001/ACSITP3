# PHARMANAGER : GESTION DES STOCKS D'UNE PHARMACIE

**PHARMANAGER**, conçu en JEE permet la gestion des stocks d'une pharmacie.

### Auteur
 [AL-FAHAMI TOIHIR](https://alfahami.github.io/ "Resume and protfolio page")
 
 [FACULTE DES SCIENCES - KENITRA](http://fs.uit.ac.ma/ "Site officiel")
 
 DEPARTEMENT DE MATHEMATIQUES ET INFORMATIQUE
 
 ### Licence: 
 Le projet est disponible en open source selon les termes de la [licence MIT](https://opensource.org/licenses/MIT).

